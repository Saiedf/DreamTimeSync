# -*- coding: utf-8 -*-
# DreamTimeSync runtime detection helpers
# Compatible with Python 2.7, 3.12, 3.13, and 3.14

from __future__ import print_function

# Created by iet5
import sys

# -- Python-version detection -------------------------------------------------
PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3
PY_MAJOR = sys.version_info[0]
PY_MINOR = sys.version_info[1]
PY_PATCH = sys.version_info[2]

# -- Compatible string helpers local to runtime detection ---------------------
try:
    text_type = unicode        # Python 2
    binary_type = str
except NameError:
    text_type = str            # Python 3
    binary_type = bytes


def _to_text(value):
    if value is None:
        return ""
    if isinstance(value, text_type):
        return value
    if isinstance(value, binary_type):
        try:
            return value.decode("utf-8", "ignore")
        except Exception:
            try:
                return value.decode("latin-1", "ignore")
            except Exception:
                return text_type(value)
    try:
        return text_type(value)
    except Exception:
        return "%s" % value

def _read_text_file(path):
    try:
        f = open(path, "rb")
        try:
            return _to_text(f.read()).strip()
        finally:
            f.close()
    except Exception:
        return ""

def _call(func):
    if func is None:
        return ""
    try:
        return _to_text(func()).strip()
    except Exception:
        return ""

def _first_non_empty(values):
    for value in values:
        value = _to_text(value).strip()
        if value:
            return value
    return ""

def _contains_any(text, needles):
    text = _to_text(text).lower()
    for needle in needles:
        if needle and needle in text:
            return True
    return False

def _starts_with_any(text, prefixes):
    text = _to_text(text).lower().strip()
    for prefix in prefixes:
        if prefix and text.startswith(prefix):
            return True
    return False

# -- Enigma2 runtime imports --------------------------------------------------
try:
    from Components.SystemInfo import BoxInfo
except Exception:
    BoxInfo = None

try:
    from boxbranding import getBoxType
except Exception:
    getBoxType = None

try:
    from boxbranding import getMachineBrand
except Exception:
    getMachineBrand = None

try:
    from boxbranding import getMachineBuild
except Exception:
    getMachineBuild = None

try:
    from boxbranding import getImageDistro
except Exception:
    getImageDistro = None

try:
    from boxbranding import getImageBuild
except Exception:
    getImageBuild = None

try:
    from boxbranding import getMachineName
except Exception:
    getMachineName = None

try:
    from boxbranding import getOEVersion
except Exception:
    getOEVersion = None

_RUNTIME_PROFILE = None

def _boxinfo(key):
    """Read a single key from BoxInfo; return empty string if unavailable."""
    if BoxInfo is None:
        return ""
    getter = getattr(BoxInfo, "getItem", None)
    if getter is None:
        try:
            return _to_text(BoxInfo[key]).strip()
        except Exception:
            return ""
    try:
        return _to_text(getter(key)).strip()
    except Exception:
        return ""

def _read_image_name():
    """Read the image/distro name from well-known locations."""
    return _first_non_empty([
        _read_text_file("/etc/opendreambox-version"),
        _read_text_file("/etc/dreambox-version"),
        _read_text_file("/etc/image-version"),
        _read_text_file("/etc/issue"),
        _read_text_file("/etc/issue.net"),
        _read_text_file("/etc/version"),
        _read_text_file("/etc/apt/sources.list"),
        _read_text_file("/etc/apt/sources.list.d/official-feed.list"),
        _read_text_file("/etc/opkg/arch.conf"),
    ])

def _read_model_from_proc():
    """Read the hardware model from /proc/stb."""
    return _first_non_empty([
        _read_text_file("/proc/stb/info/machinebuild"),
        _read_text_file("/proc/stb/info/machine"),
        _read_text_file("/proc/stb/info/hwmodel"),
        _read_text_file("/proc/stb/info/displaymodel"),
        _read_text_file("/proc/stb/info/boxmodel"),
        _read_text_file("/proc/stb/info/modelname"),
        _read_text_file("/proc/stb/info/devicename"),
        _read_text_file("/proc/stb/info/prettyname"),
        _read_text_file("/proc/stb/info/name"),
        _read_text_file("/proc/stb/info/model"),
        _read_text_file("/proc/stb/info/boxtype"),
        _read_text_file("/proc/stb/info/type"),
    ])

def _read_brand_from_proc():
    """Read the hardware brand from /proc/stb."""
    return _first_non_empty([
        _read_text_file("/proc/stb/info/oem"),
        _read_text_file("/proc/stb/info/vendor"),
        _read_text_file("/proc/stb/info/manufacturer"),
        _read_text_file("/proc/stb/info/brand"),
        _read_text_file("/proc/stb/info/manualy_name"),
    ])

def get_runtime_profile():
    """Build and cache a dict describing hardware, image, and Python runtime."""
    global _RUNTIME_PROFILE
    if _RUNTIME_PROFILE is not None:
        return _RUNTIME_PROFILE

    machine = _first_non_empty([
        _boxinfo("machinebuild"),
        _boxinfo("model"),
        _boxinfo("displaymodel"),
        _boxinfo("boxtype"),
        _call(getMachineBuild),
        _call(getBoxType),
        _call(getMachineName),
        _read_model_from_proc(),
    ]).lower()

    brand = _first_non_empty([
        _boxinfo("brand"),
        _boxinfo("displaybrand"),
        _call(getMachineBrand),
        _read_brand_from_proc(),
    ]).lower()

    image = _first_non_empty([
        _boxinfo("distro"),
        _boxinfo("imageversion"),
        _call(getImageDistro),
        _call(getImageBuild),
        _call(getOEVersion),
        _read_image_name(),
    ]).lower()

    all_text = " %s %s %s " % (machine, brand, image)

    # -- Device detection ------------------------------------------------------
    brand_is_dream = _contains_any(brand, ("dream", "dreambox"))
    if not brand_is_dream:
        proc_brand = _read_brand_from_proc().lower()
        brand_is_dream = _contains_any(proc_brand, ("dream", "dreambox"))
    image_is_dream = _contains_any(
        image,
        ("dreamos", "dreambox os", "opendreambox", "dreambox-image")
    )
    dream_context = brand_is_dream or image_is_dream

    is_dm900 = (
        _contains_any(all_text, ("dm900",)) or
        (brand_is_dream and _starts_with_any(machine, ("dm900",)))
    )

    is_dm920 = (
        _contains_any(all_text, ("dm920",)) or
        (brand_is_dream and _starts_with_any(machine, ("dm920",)))
    )

    is_dreamone = (
        _contains_any(all_text, ("dreamone", "dream one", "dreambox one", "oneultra")) or
        (dream_context and _starts_with_any(machine, ("one", "one4k", "oneultra"))) or
        machine == "one"
    )

    is_dreamtwo = (
        _contains_any(all_text, ("dreamtwo", "dream two", "dreambox two", "dreamboxtwo", "twoultra")) or
        (dream_context and _starts_with_any(machine, ("two", "two4k", "twoultra"))) or
        machine == "two"
    )

    is_dreambox = (
        is_dm900 or is_dm920 or is_dreamone or is_dreamtwo or
        brand_is_dream or image_is_dream or
        "dream" in all_text or
        " dm" in all_text
    )

    # -- Image detection -------------------------------------------------------
    is_dreamos = _contains_any(all_text, ("dreamos", "dreambox os", "opendreambox", "dreambox-image", "newnigma2", "nn2"))
    is_oe26 = (
        _contains_any(all_text, ("oe2.6", "oe 2.6", "opendreambox 2.6", "enigma2.6", "enigma 2.6")) or
        is_dreamone or is_dreamtwo
    )
    is_dreambox_oe26 = is_dreambox and is_oe26
    is_dreamone_oe26 = is_dreamone and is_oe26
    is_dreamtwo_oe26 = is_dreamtwo and is_oe26
    is_merlin = _contains_any(all_text, ("merlin",))
    is_gemini = _contains_any(all_text, ("gemini", "gp4", "geminiplugin"))
    is_dreamelite = _contains_any(all_text, ("dream elite", "dreamelite", "de image"))
    is_openatv = _contains_any(all_text, ("openatv",))
    is_openpli = _contains_any(all_text, ("openpli",))
    is_openvix = _contains_any(all_text, ("openvix",))
    is_egami = _contains_any(all_text, ("egami",))
    is_openbh = _contains_any(all_text, ("openbh", "black hole", "blackhole"))
    is_opendroid = _contains_any(all_text, ("opendroid",))
    is_vti = _contains_any(all_text, ("vti",))
    is_openspa = _contains_any(all_text, ("openspa",))
    is_openhdf = _contains_any(all_text, ("openhdf",))
    is_opennfr = _contains_any(all_text, ("opennfr",))
    is_pure2 = _contains_any(all_text, ("pure2",))
    is_satdreamgr = _contains_any(all_text, ("satdreamgr", "satdream"))

    is_oe_alliance = (
        is_openatv or is_openvix or is_openbh or is_opendroid or
        is_openhdf or is_opennfr or is_satdreamgr
    )

    target = "Generic Enigma2"
    target_code = "generic"
    if is_dreambox:
        target = "Dreambox"
        target_code = "dreambox"
    if is_dm900:
        target = "Dreambox DM900"
        target_code = "dm900"
    if is_dm920:
        target = "Dreambox DM920"
        target_code = "dm920"
    if is_dreamone:
        target = "Dreambox One"
        target_code = "dreamone"
    if is_dreamtwo:
        target = "Dreambox Two"
        target_code = "dreamtwo"

    # -- Python runtime --------------------------------------------------------
    python_major = PY_MAJOR
    python_minor = PY_MINOR
    python_patch = PY_PATCH
    is_python2 = (python_major == 2)
    is_python3 = (python_major == 3)
    is_python_312_plus = (
        python_major > 3 or
        (python_major == 3 and python_minor >= 12)
    )
    is_python_313_plus = (
        python_major > 3 or
        (python_major == 3 and python_minor >= 13)
    )
    is_python_314_plus = (
        python_major > 3 or
        (python_major == 3 and python_minor >= 14)
    )

    _RUNTIME_PROFILE = {
        "python_major": python_major,
        "python_minor": python_minor,
        "python_patch": python_patch,
        "python_version": "%s.%s.%s" % (python_major, python_minor, python_patch),
        "is_python2": is_python2,
        "is_python3": is_python3,
        "is_python_312_plus": is_python_312_plus,
        "is_python_313_plus": is_python_313_plus,
        "is_python_314_plus": is_python_314_plus,
        "machine": machine,
        "brand": brand,
        "image": image,
        "is_dm900": is_dm900,
        "is_dm920": is_dm920,
        "is_dreamone": is_dreamone,
        "is_dreamtwo": is_dreamtwo,
        "is_dreambox": is_dreambox,
        "is_oe26": is_oe26,
        "is_dreambox_oe26": is_dreambox_oe26,
        "is_dreamone_oe26": is_dreamone_oe26,
        "is_dreamtwo_oe26": is_dreamtwo_oe26,
        "is_dreamos": is_dreamos,
        "is_merlin": is_merlin,
        "is_gemini": is_gemini,
        "is_dreamelite": is_dreamelite,
        "is_openatv": is_openatv,
        "is_openpli": is_openpli,
        "is_openvix": is_openvix,
        "is_egami": is_egami,
        "is_openbh": is_openbh,
        "is_opendroid": is_opendroid,
        "is_vti": is_vti,
        "is_openspa": is_openspa,
        "is_openhdf": is_openhdf,
        "is_opennfr": is_opennfr,
        "is_pure2": is_pure2,
        "is_satdreamgr": is_satdreamgr,
        "is_oe_alliance": is_oe_alliance,
        "target": target,
        "target_code": target_code,
    }
    return _RUNTIME_PROFILE
