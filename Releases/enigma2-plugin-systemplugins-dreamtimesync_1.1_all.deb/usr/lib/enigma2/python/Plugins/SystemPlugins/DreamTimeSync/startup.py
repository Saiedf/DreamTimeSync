# -*- coding: utf-8 -*-
from __future__ import print_function

# Created by iet5
import os
import time

try:
    from Plugins.SystemPlugins.DreamTimeSync.e2compat import MessageBox, Screen, eTimer
    from Plugins.SystemPlugins.DreamTimeSync.core import (
        DEFAULT_SERVERS,
        LAST_SYNC_INFO,
        PROFILE,
        _cfg_bool,
        _cfg_text,
        _dream_config,
        _get_dvbdate_command,
        _gui,
        _log,
        _log_exception,
        _network_state,
        _set_last_sync_result,
        _timeout,
        _timer_add_callback,
        set_transponder_state,
        sync_ntp,
    )
    from Plugins.SystemPlugins.DreamTimeSync import to_text
except Exception:
    try:
        from .e2compat import MessageBox, Screen, eTimer
        from .core import (
            DEFAULT_SERVERS,
            LAST_SYNC_INFO,
            PROFILE,
            _cfg_bool,
            _cfg_text,
            _dream_config,
            _get_dvbdate_command,
            _gui,
            _log,
            _log_exception,
            _network_state,
            _set_last_sync_result,
            _timeout,
            _timer_add_callback,
            set_transponder_state,
            sync_ntp,
        )
        from . import to_text
    except Exception:
        from e2compat import MessageBox, Screen, eTimer
        from core import (
            DEFAULT_SERVERS,
            LAST_SYNC_INFO,
            PROFILE,
            _cfg_bool,
            _cfg_text,
            _dream_config,
            _get_dvbdate_command,
            _gui,
            _log,
            _log_exception,
            _network_state,
            _set_last_sync_result,
            _timeout,
            _timer_add_callback,
            set_transponder_state,
            sync_ntp,
        )
        from __init__ import to_text

SESSION = None
STARTUP_TIMER_OBJ = None
STARTUP_WORKER_OBJ = None
STARTUP_RETRY_COUNT = 0
STARTUP_RETRY_DELAYS = (10000, 25000, 45000)
STARTUP_ALREADY_REQUESTED = False
POPUP_TIMERS = []
STARTUP_POPUP_SHOWN = False
STARTUP_DELAY_MS = 3000
HEADLESS_START_DELAY_MS = 500
STARTUP_POPUP_TIMEOUT = 10

def _is_dream_oe26():
    return bool(
        PROFILE.get("is_dreamone_oe26") or
        PROFILE.get("is_dreamtwo_oe26")
    )


def _startup_popup(session, text, ok, startup=False, timeout=STARTUP_POPUP_TIMEOUT):
    global STARTUP_POPUP_SHOWN
    _log("popup requested: ok=%s startup=%s timeout=%s session=%s text=%s" % (ok, startup, timeout, session is not None, to_text(text).replace("\n", " | ")))

    # Show the startup popup only once per Enigma2 boot.
    # Do not use AddPopup/AddNotification together with session.open here,
    # because that can create duplicate or delayed repeated popups on some images.
    if startup and STARTUP_POPUP_SHOWN:
        _log("startup popup skipped: already shown once in this session")
        return False

    if MessageBox is None:
        _log("popup failed: MessageBox is None")
        return False
    if session is None:
        _log("popup failed: session is None")
        return False

    box_type = getattr(MessageBox, "TYPE_INFO", 0) if ok else getattr(MessageBox, "TYPE_ERROR", 0)
    try:
        session.open(MessageBox, _gui(text), type=box_type, timeout=timeout)
        if startup:
            STARTUP_POPUP_SHOWN = True
        _log("single popup opened via session.open keyword; auto-close timeout=%s seconds" % timeout)
        return True
    except Exception as err:
        _log_exception("single popup keyword form failed", err)
        try:
            session.open(MessageBox, _gui(text), box_type, timeout=timeout)
            if startup:
                STARTUP_POPUP_SHOWN = True
            _log("single popup opened via session.open positional; auto-close timeout=%s seconds" % timeout)
            return True
        except Exception as err2:
            _log_exception("single popup positional form failed", err2)

    _log("popup failed: no session.open method worked")
    return False


def _safe_startup_popup(session, text, ok, startup=True, timeout=STARTUP_POPUP_TIMEOUT):
    if startup and _is_dream_oe26():
        _log("Dream One/Two OE2.6 condition: using delayed startup popup")
        return _delayed_startup_popup(session, text, ok, delay_ms=1500, startup=startup, timeout=timeout)
    return _startup_popup(session, text, ok, startup=startup, timeout=timeout)


def _delayed_startup_popup(session, text, ok, delay_ms=800, startup=True, timeout=STARTUP_POPUP_TIMEOUT):
    _log("delayed popup requested after %s ms" % delay_ms)
    if eTimer is None:
        return _startup_popup(session, text, ok, startup=startup, timeout=timeout)
    try:
        t = eTimer()
        POPUP_TIMERS.append(t)
        def _fire():
            try:
                _log("delayed popup timer fired")
                _startup_popup(session or SESSION, text, ok, startup=startup, timeout=timeout)
            finally:
                try:
                    POPUP_TIMERS.remove(t)
                except Exception:
                    pass
        if _timer_add_callback(t, _fire):
            t.start(delay_ms, True)
            _log("delayed popup timer started")
            return True
        _log("delayed popup timer callback failed; showing immediately")
        return _startup_popup(session, text, ok, startup=startup, timeout=timeout)
    except Exception as err:
        _log_exception("delayed popup setup failed", err)
        return _startup_popup(session, text, ok, startup=startup, timeout=timeout)



def _dvb_instruction_message(reason=None):
    base = "NTP time update failed or internet connection is not available."
    if reason:
        base += "\n\nReason: %s" % to_text(reason)
    base += "\n\nPlease switch to a TV channel/transponder that provides DVB time service, then wait a few seconds for the receiver to read the broadcast time."
    base += "\n\nIf 'Use DVB fallback on startup' is enabled, transponder time will be enabled automatically."
    return base


def _enable_dvb_fallback_if_configured(reason):
    try:
        c = _dream_config()
        if c is not None and _cfg_bool(getattr(c, "checkDvbOnStart", None), False):
            _log("enabling DVB/transponder time fallback after NTP failure: %s" % to_text(reason))
            ok = set_transponder_state(True)
            if ok:
                msg = "transponder time enabled"
            else:
                msg = "transponder time could not be enabled"
            _log("DVB/transponder fallback enable result: ok=%s msg=%s" % (ok, msg))
            dvb_cmd = _get_dvbdate_command("set")
            if dvb_cmd:
                _log("running dvbdate fallback command: %s" % dvb_cmd)
                try:
                    os.system(dvb_cmd)
                except Exception as err:
                    _log_exception("dvbdate fallback command failed", err)
            return bool(ok)
        _log("DVB/transponder fallback not enabled in config; showing instruction only")
    except Exception as err:
        _log_exception("DVB fallback condition failed", err)
    return False


def _startup_should_retry(message):
    text = to_text(message).lower()
    retryable_markers = (
        "network is unreachable",
        "no ntp server replied",
        "dns lookup failed",
        "timed out",
        "no reply",
        "temporary failure",
    )
    for marker in retryable_markers:
        if marker in text:
            return True
    return False


def _run_startup_sync_from_session():
    global SESSION
    if SESSION is None:
        _log("startup sync skipped: no session")
        return
    try:
        c = _dream_config()
        if c is None:
            _log("delayed startup: config is not available")
            return
        if _cfg_bool(getattr(c, "syncOnStart", None), True):
            _log("delayed startup starting headless NTP worker")
            _start_headless_ntp_startup(SESSION)
        elif _cfg_bool(getattr(c, "checkDvbOnStart", None), False):
            _log("delayed startup opening DVBStartup")
            SESSION.open(DVBStartup)
        else:
            _log("delayed startup: no startup option enabled")
    except Exception as err:
        _log_exception("delayed startup error", err)


def _startup_timer_fired():
    _log("startup timer fired")
    _run_startup_sync_from_session()


def _schedule_startup_sync(reset=False, delay_ms=STARTUP_DELAY_MS):
    global STARTUP_TIMER_OBJ, STARTUP_RETRY_COUNT
    if eTimer is None:
        _log("startup schedule fallback: eTimer is None, running directly")
        _run_startup_sync_from_session()
        return False
    if reset:
        STARTUP_RETRY_COUNT = 0
    try:
        if STARTUP_TIMER_OBJ is not None:
            try:
                STARTUP_TIMER_OBJ.stop()
                _log("old startup timer stopped")
            except Exception as err:
                _log_exception("old startup timer stop failed", err)
        STARTUP_TIMER_OBJ = eTimer()
        _log("startup timer object created: %s" % to_text(STARTUP_TIMER_OBJ))
        if _timer_add_callback(STARTUP_TIMER_OBJ, _startup_timer_fired):
            STARTUP_TIMER_OBJ.start(int(delay_ms), True)
            _log("startup sync scheduled after %s ms" % int(delay_ms))
            return True
        _log("startup schedule: callback add returned False")
    except Exception as err:
        _log_exception("startup schedule error", err)
    _run_startup_sync_from_session()
    return False



class HeadlessNTPStartup(object):
    """Run startup NTP sync without opening any visible Screen."""

    def __init__(self, session):
        self.session = session
        self.timer = eTimer() if eTimer is not None else None
        self.safety_timer = eTimer() if eTimer is not None else None
        self.fired = False
        _log("HeadlessNTPStartup initialized; no visible startup screen will be opened")
        if self.timer is None:
            _log("HeadlessNTPStartup: eTimer is None; running immediately")
            self.start_sync()
        elif not _timer_add_callback(self.timer, self.start_sync):
            _log("HeadlessNTPStartup timer callback failed; running immediately")
            self.start_sync()
        else:
            self.timer.start(int(HEADLESS_START_DELAY_MS), True)
            _log("HeadlessNTPStartup timer started after %s ms" % int(HEADLESS_START_DELAY_MS))

        if self.safety_timer is not None:
            if _timer_add_callback(self.safety_timer, self.close):
                self.safety_timer.start(20000, True)
                _log("HeadlessNTPStartup safety timer started after 20000 ms")

    def close(self):
        global STARTUP_WORKER_OBJ
        try:
            if self.timer is not None:
                self.timer.stop()
        except Exception:
            pass
        try:
            if self.safety_timer is not None:
                self.safety_timer.stop()
        except Exception:
            pass
        STARTUP_WORKER_OBJ = None
        _log("HeadlessNTPStartup closed")

    def start_sync(self):
        if self.fired:
            return
        self.fired = True
        _log("HeadlessNTPStartup.start_sync triggered")
        is_online, state_text = _network_state()

        if is_online is False:
            _log("network unreachable, skipping sync")
            reason = "Network is unreachable."
            _set_last_sync_result(False, "Startup sync", "network", reason)
            c = _dream_config()
            _enable_dvb_fallback_if_configured(reason)
            if _cfg_bool(getattr(c, "showMessages", None), True):
                _safe_startup_popup(self.session, _dvb_instruction_message(reason), False, startup=True, timeout=STARTUP_POPUP_TIMEOUT)
            self.close()
            return

        ok, msg = sync_ntp("Startup sync")
        _log("headless sync result: %s message=%s" % (ok, msg))

        c = _dream_config()
        if not ok:
            _enable_dvb_fallback_if_configured(msg)
            if _cfg_bool(getattr(c, "showMessages", None), True):
                _safe_startup_popup(self.session, _dvb_instruction_message(msg), False, startup=True, timeout=STARTUP_POPUP_TIMEOUT)
        else:
            if _cfg_bool(getattr(c, "showMessages", None), True):
                timenow = time.strftime("%Y-%m-%d %H:%M:%S")
                server_name = LAST_SYNC_INFO.get("server", "n/a")
                msg_text = "NTP time check completed successfully.\nSystem time is now set to %s.\nServer: %s" % (timenow, server_name)
                _log("showing startup popup from headless worker")
                _safe_startup_popup(self.session, msg_text, True, startup=True, timeout=STARTUP_POPUP_TIMEOUT)
        self.close()


def _start_headless_ntp_startup(session):
    global STARTUP_WORKER_OBJ
    try:
        STARTUP_WORKER_OBJ = HeadlessNTPStartup(session)
        _log("headless startup worker object stored")
        return True
    except Exception as err:
        _log_exception("headless startup worker failed", err)
        try:
            _log("fallback: opening legacy NTPStartup screen")
            session.open(NTPStartup)
        except Exception as err2:
            _log_exception("legacy NTPStartup fallback failed", err2)
        return False

class NTPStartup(Screen):
    # Legacy fallback only. Keep invisible to avoid a blank boot box.
    skin = """<screen position="-200,-200" size="1,1" title=" " flags="wfNoBorder" ></screen>"""

    def __init__(self, session):
        self.skin = NTPStartup.skin
        self.session = session
        Screen.__init__(self, session)
        _log("NTPStartup initialized")
        self.timer = eTimer() if eTimer is not None else None
        self.fired = False
        _log("NTPStartup timer created: eTimer=%s" % (eTimer is not None))
        # Ported exactly from old version: connect timeout signal
        if self.timer is None:
            _log("NTPStartup: eTimer is None; running immediately")
            self.start_sync()
        elif not _timer_add_callback(self.timer, self.start_sync):
            _log("NTPStartup timer callback failed; running immediately")
            self.start_sync()
        else:
            # Old version used 3000ms
            self.timer.start(3000, True)
            _log("NTPStartup timer started after 3000 ms")
            
        # Safety fallback
        self.safety_timer = eTimer() if eTimer is not None else None
        if self.safety_timer is not None and _timer_add_callback(self.safety_timer, self.close):
            self.safety_timer.start(20000, True)
            _log("NTPStartup safety timer started after 20000 ms")

    def start_sync(self):
        if self.fired:
            return
        self.fired = True
        _log("NTPStartup.start_sync triggered")
        is_online, state_text = _network_state()
        
        if is_online is False:
            _log("network unreachable, skipping sync")
            _set_last_sync_result(False, "Startup sync", "network", "Network is unreachable.")
            c = _dream_config()
            if _cfg_bool(getattr(c, "showMessages", None), True):
                self.close()
                _delayed_startup_popup(SESSION or self.session, "NTP check is not possible because the network is unreachable.", False)
            else:
                self.close()
            return

        # Perform NTP sync
        ok, msg = sync_ntp("Startup sync")
        _log("sync result: %s message=%s" % (ok, msg))
        
        if not ok:
            # Ported from old version: try DVB fallback if enabled
            c = _dream_config()
            if _cfg_bool(getattr(c, "checkDvbOnStart", None), False):
                _log("NTP failed, trying DVB fallback")
                self.session.open(DVBStartup)
            
            c = _dream_config()
            if _cfg_bool(getattr(c, "showMessages", None), True):
                self.close()
                _delayed_startup_popup(SESSION or self.session, "The startup NTP update failed.\n\n%s" % msg, False)
                return
        else:
            c = _dream_config()
            if _cfg_bool(getattr(c, "showMessages", None), True):
                timenow = time.strftime("%Y-%m-%d %H:%M:%S")
                server_name = LAST_SYNC_INFO.get("server", "n/a")
                msg_text = "NTP time check completed successfully.\nSystem time is now set to %s.\nServer: %s" % (timenow, server_name)
                _log("showing startup popup")
                self.close()
                _delayed_startup_popup(SESSION or self.session, msg_text, True)
                return
        self.close()

class DVBStartup(Screen):
    # Invisible fallback screen for old images that require a Screen instance.
    skin = """<screen position="-200,-200" size="1,1" title=" " flags="wfNoBorder" ></screen>"""

    def __init__(self, session):
        self.skin = DVBStartup.skin
        self.session = session
        Screen.__init__(self, session)
        self.timer = eTimer() if eTimer is not None else None
        if self.timer is None:
            self.run_dvb()
        elif not _timer_add_callback(self.timer, self.run_dvb):
            self.run_dvb()
        else:
            self.timer.start(1000, True)

    def run_dvb(self):
        _log("DVBStartup fallback triggered")
        # Try binary first if available
        dvb_cmd = _get_dvbdate_command("set")
        if dvb_cmd:
            _log("using dvbdate binary: %s" % dvb_cmd)
            os.system(dvb_cmd)
        
        # Always set the Enigma2 config flag as a fallback
        set_transponder_state(True)
        
        if MessageBox is not None:
            self.session.open(MessageBox, _gui("DVB fallback has been enabled."), getattr(MessageBox, "TYPE_INFO", 0), timeout=STARTUP_POPUP_TIMEOUT)
        self.close()


def sessionstart(reason, session=None, **kwargs):
    global SESSION, STARTUP_ALREADY_REQUESTED
    if session is None:
        session = kwargs.get("session")
    if session is not None:
        SESSION = session

    _log("sessionstart called, reason=%s, session_ready=%s" % (reason, SESSION is not None))
    try:
        reason_is_start = int(reason) == 0
    except Exception:
        reason_is_start = (to_text(reason) == "0")
    if reason_is_start:
        try:
            c = _dream_config()
            _log("startup config: syncOnStart=%s showMessages=%s checkDvbOnStart=%s servers=%s timeout=%s" % (
                _cfg_bool(getattr(c, "syncOnStart", None), True),
                _cfg_bool(getattr(c, "showMessages", None), True),
                _cfg_bool(getattr(c, "checkDvbOnStart", None), False),
                _cfg_text(getattr(c, "servers", None), DEFAULT_SERVERS),
                _timeout(),
            ))
        except Exception as err:
            _log_exception("startup config read failed", err)
        if SESSION is not None:
            if STARTUP_ALREADY_REQUESTED:
                _log("startup already requested once; ignoring duplicate sessionstart")
            else:
                STARTUP_ALREADY_REQUESTED = True
                _schedule_startup_sync(reset=True, delay_ms=STARTUP_DELAY_MS)
        else:
            _log("sessionstart reason 0 but SESSION is None")




