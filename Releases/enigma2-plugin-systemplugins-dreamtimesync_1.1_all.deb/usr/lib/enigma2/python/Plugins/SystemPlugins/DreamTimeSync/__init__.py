# -*- coding: utf-8 -*-
from __future__ import print_function

# Created by iet5
import os

# -- Plugin identity ----------------------------------------------------------
PLUGIN_NAME = "Dream Time Sync"
PLUGIN_DOMAIN = "DreamTimeSync"
PLUGIN_SCOPE_PATH = "SystemPlugins/DreamTimeSync"


# -- Compatible string types (Python 2 and 3) --------------------------------
try:
    text_type = unicode        # Python 2
    binary_type = str
    PY2 = True
except NameError:
    text_type = str            # Python 3
    binary_type = bytes
    PY2 = False

PY3 = not PY2


# -- Enigma2 plugin path imports ---------------------------------------------
try:
    from Tools.Directories import SCOPE_PLUGINS, resolveFilename
except Exception:
    SCOPE_PLUGINS = None
    resolveFilename = None


# -- Translation stub (Enigma2 gettext is set up at import time) --------------
def _(txt):
    """Return the translated string; falls back to the original if unavailable."""
    return txt


# -- General small helpers ----------------------------------------------------
def compat_print(*args):
    """Print without raising exceptions on broken stdout."""
    try:
        print(*args)
    except Exception:
        pass


def to_text(value):
    """Convert any value to a native text string."""
    if value is None:
        return ""
    if isinstance(value, text_type):
        return value
    if isinstance(value, binary_type):
        try:
            return value.decode("utf-8", "ignore")
        except Exception:
            try:
                return value.decode("latin-1", "ignore")
            except Exception:
                return text_type(value)
    try:
        return text_type(value)
    except Exception:
        return "%s" % value


def to_gui_text(value):
    """Return a string safe for Enigma2 GUI widgets."""
    value = to_text(value)
    if PY2:
        try:
            return value.encode("utf-8")
        except Exception:
            try:
                return value.encode("latin-1", "ignore")
            except Exception:
                return str(value)
    return value


def _read_text_file(path):
    """Read a text file safely; return empty string on any error."""
    try:
        f = open(path, "rb")
        try:
            return to_text(f.read()).strip()
        finally:
            f.close()
    except Exception:
        return ""


def _first_non_empty(values):
    """Return the first non-empty string from a list."""
    for value in values:
        value = to_text(value).strip()
        if value:
            return value
    return ""


def get_plugin_dir():
    """Return the absolute directory that contains this plugin."""
    plugin_dir = ""
    if resolveFilename is not None and SCOPE_PLUGINS is not None:
        try:
            plugin_dir = resolveFilename(SCOPE_PLUGINS, PLUGIN_SCOPE_PATH)
        except Exception:
            plugin_dir = ""
    if not plugin_dir or not os.path.isdir(plugin_dir):
        plugin_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.normpath(plugin_dir)


PLUGIN_DIR = get_plugin_dir()
PLUGIN_VERSION_FILE = os.path.join(PLUGIN_DIR, "ver.txt")


def get_plugin_version():
    """Return the plugin version string from ver.txt."""
    version = _read_text_file(PLUGIN_VERSION_FILE)
    if version:
        return version.split()[0]
    return "1.0"


PLUGIN_VERSION = get_plugin_version()


def get_asset_path(name):
    """Return the absolute path of a plugin asset file."""
    return os.path.join(PLUGIN_DIR, name)


def get_runtime_profile():
    """Backward-compatible wrapper; runtime detection lives in runtime.py."""
    try:
        from Plugins.SystemPlugins.DreamTimeSync.runtime import get_runtime_profile as _runtime_profile
    except Exception:
        try:
            from .runtime import get_runtime_profile as _runtime_profile
        except Exception:
            from runtime import get_runtime_profile as _runtime_profile
    return _runtime_profile()
