# -*- coding: utf-8 -*-
from __future__ import print_function

# Created by iet5
import os
import socket
import struct
import time

try:
    from Plugins.SystemPlugins.DreamTimeSync import (
        _,
        PLUGIN_DIR,
        PLUGIN_NAME,
        compat_print,
        get_asset_path,
        get_plugin_version,
        to_gui_text,
        to_text,
    )
    from Plugins.SystemPlugins.DreamTimeSync.runtime import get_runtime_profile
except Exception:
    try:
        from . import (
            _,
            PLUGIN_DIR,
            PLUGIN_NAME,
            compat_print,
            get_asset_path,
            get_plugin_version,
            to_gui_text,
            to_text,
        )
        from .runtime import get_runtime_profile
    except Exception:
        from __init__ import (
            _,
            PLUGIN_DIR,
            PLUGIN_NAME,
            compat_print,
            get_asset_path,
            get_plugin_version,
            to_gui_text,
            to_text,
        )
        from runtime import get_runtime_profile

try:
    from Plugins.SystemPlugins.DreamTimeSync.e2compat import (
        ConfigBoolean,
        ConfigInteger,
        ConfigSelection,
        ConfigSubsection,
        ConfigText,
        ConfigYesNo,
        config,
        eTimeManager,
        gFont,
        getConfigListEntry,
        iNetwork,
        iNetworkInfo,
        readKeymap,
    )
except Exception:
    try:
        from .e2compat import (
            ConfigBoolean,
            ConfigInteger,
            ConfigSelection,
            ConfigSubsection,
            ConfigText,
            ConfigYesNo,
            config,
            eTimeManager,
            gFont,
            getConfigListEntry,
            iNetwork,
            iNetworkInfo,
            readKeymap,
        )
    except Exception:
        from e2compat import (
            ConfigBoolean,
            ConfigInteger,
            ConfigSelection,
            ConfigSubsection,
            ConfigText,
            ConfigYesNo,
            config,
            eTimeManager,
            gFont,
            getConfigListEntry,
            iNetwork,
            iNetworkInfo,
            readKeymap,
        )

VERSION = get_plugin_version()

LOG_FILE = "/tmp/DreamTimeSync.log"

def _log(message):
    try:
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        stamp = "0000-00-00 00:00:00"
    try:
        line = "[DreamTimeSync] %s %s\n" % (stamp, to_text(message))
    except Exception:
        try:
            line = "[DreamTimeSync] %s %s\n" % (stamp, str(message))
        except Exception:
            line = "[DreamTimeSync] %s <log conversion failed>\n" % stamp
    try:
        with open(LOG_FILE, "a") as log_handle:
            log_handle.write(line)
    except Exception:
        pass
    try:
        compat_print(line.rstrip())
    except Exception:
        try:
            print(line.rstrip())
        except Exception:
            pass

def _log_exception(context, err):
    try:
        _log("%s: %s" % (context, to_text(err)))
    except Exception:
        _log(context)


PROFILE = get_runtime_profile()
PLUGIN_ICON = "plugin.png"
NTP_PACKET_SIZE = 48
NTP_PORT = 123
NTP_UNIX_EPOCH_DELTA = 2208988800
DEFAULT_SERVERS = "0.pool.ntp.org,1.pool.ntp.org,time.google.com,time.cloudflare.com"
TIMER_CONNECTIONS = []
PLUGIN_KEYMAP = get_asset_path("keymap.xml")
KEYMAP_LOADED = False
_log("module loaded: version=%s target=%s python=%s machine=%s brand=%s image=%s log=%s" % (
    VERSION,
    PROFILE.get("target", "Unknown"),
    PROFILE.get("python_version", "Unknown"),
    PROFILE.get("machine", ""),
    PROFILE.get("brand", ""),
    PROFILE.get("image", ""),
    LOG_FILE,
))
LAST_SYNC_INFO = {
    "ok": None,
    "mode": "NTP",
    "server": "",
    "summary": "Never synced",
    "details": "No NTP synchronization has been attempted yet.",
    "timestamp": "",
}


def _gui(value):
    return to_gui_text(value)


def _load_plugin_keymap():
    global KEYMAP_LOADED
    if KEYMAP_LOADED or readKeymap is None:
        return False
    try:
        if os.path.exists(PLUGIN_KEYMAP):
            readKeymap(PLUGIN_KEYMAP)
            KEYMAP_LOADED = True
            _log("keymap loaded: %s" % PLUGIN_KEYMAP)
            return True
    except Exception as err:
        _log_exception("keymap load error", err)
    return False


_load_plugin_keymap()


def _normalize_server_text(raw):
    text = to_text(raw).replace(";", ",").replace("\r", ",").replace("\n", ",")
    servers = []
    for item in text.split(","):
        server = item.strip()
        if not server:
            continue
        if server not in servers:
            servers.append(server)
    if not servers:
        return DEFAULT_SERVERS
    return ",".join(servers)


def _get_dvbdate_command(mode):
    # Try to find dvbdate binary in standard locations
    for path in ("/usr/bin/dvbdate", "/bin/dvbdate", "/usr/sbin/dvbdate", "/sbin/dvbdate"):
        if os.path.exists(path):
            if mode == "print":
                return "%s --print" % path
            if mode == "set":
                return "%s --set" % path
            if mode == "force":
                return "%s --set --force" % path
            return path
    return ""


def _set_last_sync_result(ok, mode, server, message):

    global LAST_SYNC_INFO
    state_text = ok and "SUCCESS" or "FAILED"
    mode_text = to_text(mode or "NTP").strip() or "NTP"
    server_text = to_text(server or "n/a").strip() or "n/a"
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    summary = "%s | %s | %s" % (mode_text, time.strftime("%H:%M:%S"), server_text)
    details = "Result: %s\nMode: %s\nServer: %s\nTime: %s\nMessage: %s" % (
        state_text,
        mode_text,
        server_text,
        timestamp,
        to_text(message or ""),
    )
    LAST_SYNC_INFO.clear()
    LAST_SYNC_INFO.update({
        "ok": bool(ok),
        "mode": mode_text,
        "server": server_text,
        "summary": summary,
        "details": details,
        "timestamp": timestamp,
        "state_text": state_text,
    })
    _log("sync result updated: %s | %s" % (state_text, summary))


def _last_sync_summary():
    return LAST_SYNC_INFO.get("summary", "Never synced")


def _last_sync_summary_display():
    summary = _last_sync_summary()
    ok = LAST_SYNC_INFO.get("ok", None)
    if ok is True:
        return "\\cFF7CCF4D[SUCCESS]\\cFFFFFFFF | %s" % summary
    if ok is False:
        return "\\cFFB22222[FAILED]\\cFFFFFFFF | %s" % summary
    return "[NOT RUN YET] | %s" % summary


def _last_sync_details():
    return LAST_SYNC_INFO.get("details", "No NTP synchronization has been attempted yet.")


def _timer_add_callback(timer, callback):
    if timer is None:
        _log("timer callback add failed: timer is None")
        return False

    # Prefer the classic Enigma2 callback list first. On some DreamOS images
    # timeout.connect appears to accept the callback but the timer never fires.
    try:
        timer_callback = getattr(timer, "callback", None)
        if timer_callback is not None:
            if callback not in timer_callback:
                timer_callback.append(callback)
            _log("timer callback added via timer.callback for %s" % getattr(callback, "__name__", "callback"))
            return True
    except Exception as err:
        _log_exception("timer.callback append failed", err)

    try:
        timeout = getattr(timer, "timeout", None)
        if timeout is not None and hasattr(timeout, "get"):
            callbacks = timeout.get()
            if callback not in callbacks:
                callbacks.append(callback)
            _log("timer callback added via timeout.get().append for %s" % getattr(callback, "__name__", "callback"))
            return True
    except Exception as err:
        _log_exception("timer timeout.get append failed", err)

    try:
        timeout = getattr(timer, "timeout", None)
        if timeout is not None and hasattr(timeout, "connect"):
            connection = timeout.connect(callback)
            try:
                TIMER_CONNECTIONS.append(connection)
            except Exception:
                pass
            _log("timer callback added via timeout.connect for %s" % getattr(callback, "__name__", "callback"))
            return True
    except Exception as err:
        _log_exception("timer timeout.connect failed", err)

    _log("timer callback add failed: no compatible callback API")
    return False


def _dream_config():
    try:
        return config.plugins.DreamTimeSync
    except Exception:
        return None


def _create_bool_config(default_value=False):
    for cls in (ConfigYesNo, ConfigBoolean):
        if cls is None:
            continue
        try:
            return cls(default=bool(default_value))
        except TypeError:
            try:
                return cls(bool(default_value))
            except Exception:
                pass
        except Exception:
            pass
    return None


def _create_integer_config(default_value, limits=None):
    if ConfigInteger is None:
        return None
    if limits is not None:
        try:
            return ConfigInteger(default=default_value, limits=limits)
        except TypeError:
            pass
        except Exception:
            return None
    try:
        return ConfigInteger(default=default_value)
    except TypeError:
        try:
            return ConfigInteger(default_value)
        except Exception:
            return None
    except Exception:
        return None


def _create_selection_config(choices, default_value):
    if ConfigSelection is None:
        return None
    for kwargs in (
        {"choices": choices, "default": default_value},
        {"choices": choices},
    ):
        try:
            return ConfigSelection(**kwargs)
        except TypeError:
            continue
        except Exception:
            return None
    try:
        return ConfigSelection(choices, default_value)
    except Exception:
        return None


def _append_config_entry(entries, label, item):
    if getConfigListEntry is None or item is None:
        return False
    try:
        entries.append(getConfigListEntry(_gui(label), item))
        return True
    except Exception as err:
        _log_exception("config entry add failed for %s" % label, err)
    return False


def _save_config_item(item):
    if item is None:
        return False
    try:
        item.save()
        return True
    except Exception:
        return False


def _create_servers_config(default_value):
    if ConfigText is None:
        return None
    for kwargs in (
        {"default": default_value, "fixed_size": False, "visible_width": 128},
        {"default": default_value, "fixed_size": False, "visible_width": 96},
        {"default": default_value, "fixed_size": False},
        {"default": default_value},
    ):
        try:
            return ConfigText(**kwargs)
        except TypeError:
            continue
        except Exception:
            break
    try:
        return ConfigText(default=default_value)
    except Exception:
        return None


def _get_image_family_label():
    # Each image family has its own isolated condition
    if PROFILE.get("is_dreamone_oe26"):
        return "Dreambox One OE2.6"
    if PROFILE.get("is_dreamtwo_oe26"):
        return "Dreambox Two OE2.6"
    if PROFILE.get("is_dreamos"):
        return "DreamOS"
    if PROFILE.get("is_merlin"):
        return "Merlin"
    if PROFILE.get("is_gemini"):
        return "Gemini"
    if PROFILE.get("is_dreamelite"):
        return "Dream-Elite"
    if PROFILE.get("is_openatv"):
        return "OpenATV"
    if PROFILE.get("is_openpli"):
        return "OpenPLi"
    if PROFILE.get("is_openvix"):
        return "OpenViX"
    if PROFILE.get("is_openbh"):
        return "OpenBH"
    if PROFILE.get("is_opendroid"):
        return "OpenDroid"
    if PROFILE.get("is_egami"):
        return "Egami"
    if PROFILE.get("is_vti"):
        return "VTi"
    if PROFILE.get("is_openspa"):
        return "OpenSPA"
    if PROFILE.get("is_openhdf"):
        return "OpenHDF"
    if PROFILE.get("is_opennfr"):
        return "OpenNFR"
    if PROFILE.get("is_pure2"):
        return "PurE2"
    if PROFILE.get("is_satdreamgr"):
        return "SatDreamGr"
    return "Generic image"


def _get_ui_profile():
    ui = {
        "config_separation": 470,
        "config_font": 30,
        "config_item_height": 56,
    }

    # -- Per-device conditions (isolated - do NOT merge into a single elif chain) --
    specific_dreambox = (
        PROFILE.get("is_dm900") or
        PROFILE.get("is_dm920") or
        PROFILE.get("is_dreamone") or
        PROFILE.get("is_dreamtwo")
    )
    if PROFILE.get("is_dm900"):
        ui["config_separation"] = 430
        ui["config_font"] = 28
        ui["config_item_height"] = 54
    if PROFILE.get("is_dm920"):
        ui["config_separation"] = 430
        ui["config_font"] = 28
        ui["config_item_height"] = 54
    if PROFILE.get("is_dreamone"):
        ui["config_separation"] = 500
        ui["config_font"] = 30
        ui["config_item_height"] = 56
    if PROFILE.get("is_dreamtwo"):
        ui["config_separation"] = 500
        ui["config_font"] = 30
        ui["config_item_height"] = 56
    if PROFILE.get("is_dreamone_oe26"):
        ui["config_separation"] = 460
        ui["config_font"] = 28
        ui["config_item_height"] = 54
    if PROFILE.get("is_dreamtwo_oe26"):
        ui["config_separation"] = 460
        ui["config_font"] = 28
        ui["config_item_height"] = 54
    if PROFILE.get("is_dreambox") and not specific_dreambox:
        ui["config_separation"] = 450
        ui["config_font"] = 28
        ui["config_item_height"] = 54

    # -- Per-image conditions (isolated) --------------------------------------
    if PROFILE.get("is_dreamos"):
        ui["config_separation"] = min(ui["config_separation"], 460)
    if PROFILE.get("is_merlin"):
        ui["config_separation"] = min(ui["config_separation"], 460)
    if PROFILE.get("is_gemini"):
        ui["config_separation"] = min(ui["config_separation"], 460)
    if PROFILE.get("is_dreamelite"):
        ui["config_separation"] = min(ui["config_separation"], 460)
    if PROFILE.get("is_openatv"):
        ui["config_separation"] = min(ui["config_separation"], 480)
    if PROFILE.get("is_openpli"):
        ui["config_separation"] = min(ui["config_separation"], 490)
    if PROFILE.get("is_openvix"):
        ui["config_separation"] = min(ui["config_separation"], 480)
    if PROFILE.get("is_openbh"):
        ui["config_separation"] = min(ui["config_separation"], 480)
    if PROFILE.get("is_opendroid"):
        ui["config_separation"] = min(ui["config_separation"], 485)
    if PROFILE.get("is_egami"):
        ui["config_separation"] = min(ui["config_separation"], 490)
    if PROFILE.get("is_vti"):
        ui["config_separation"] = min(ui["config_separation"], 480)
    if PROFILE.get("is_openspa"):
        ui["config_separation"] = min(ui["config_separation"], 490)
    if PROFILE.get("is_openhdf"):
        ui["config_separation"] = min(ui["config_separation"], 480)
    if PROFILE.get("is_opennfr"):
        ui["config_separation"] = min(ui["config_separation"], 480)
    if PROFILE.get("is_pure2"):
        ui["config_separation"] = min(ui["config_separation"], 490)
    if PROFILE.get("is_satdreamgr"):
        ui["config_separation"] = min(ui["config_separation"], 490)

    # -- Per-Python-version conditions (isolated) ------------------------------
    if PROFILE.get("is_python2"):
        ui["config_font"] = min(ui["config_font"], 28)
        ui["config_item_height"] = min(ui["config_item_height"], 54)
        ui["config_separation"] = min(ui["config_separation"], 450)
    if PROFILE.get("is_python_312_plus"):
        ui["config_font"] = max(ui["config_font"], 29)
    if PROFILE.get("is_python_313_plus"):
        ui["config_font"] = max(ui["config_font"], 30)
    if PROFILE.get("is_python_314_plus"):
        ui["config_font"] = max(ui["config_font"], 30)

    return ui


def _apply_config_profile(config_widget, ui_profile):
    config_list = getattr(config_widget, "l", None)
    if config_list is None:
        return
    try:
        config_list.setSeperation(int(ui_profile.get("config_separation", 470)))
    except Exception:
        try:
            config_list.setSeparation(int(ui_profile.get("config_separation", 470)))
        except Exception:
            pass
    try:
        config_list.setItemHeight(int(ui_profile.get("config_item_height", 56)))
    except Exception:
        pass


def _ensure_config():
    if config is None or ConfigSubsection is None:
        return
    if not hasattr(config, "plugins"):
        return
    if not hasattr(config.plugins, "DreamTimeSync"):
        config.plugins.DreamTimeSync = ConfigSubsection()
    c = config.plugins.DreamTimeSync
    if not hasattr(c, "syncOnStart"):
        item = _create_bool_config(True)
        if item is not None:
            c.syncOnStart = item
    if not hasattr(c, "showMessages"):
        item = _create_bool_config(True)
        if item is not None:
            c.showMessages = item
    if not hasattr(c, "preferNtp"):
        item = _create_bool_config(True)
        if item is not None:
            c.preferNtp = item
    if not hasattr(c, "allowDvbTime"):
        item = _create_bool_config(True)
        if item is not None:
            c.allowDvbTime = item
    if not hasattr(c, "servers"):
        item = _create_servers_config(DEFAULT_SERVERS)
        if item is not None:
            c.servers = item
    if not hasattr(c, "timeout"):
        item = _create_integer_config(4, limits=(1, 15))
        if item is not None:
            c.timeout = item
    if not hasattr(c, "checkDvbOnStart"):
        item = _create_bool_config(False)
        if item is not None:
            c.checkDvbOnStart = item
    if not hasattr(c, "updateEnigmaTime"):
        item = _create_bool_config(True)
        if item is not None:
            c.updateEnigmaTime = item
    if not hasattr(c, "forceDvbUpdate"):
        item = _create_bool_config(False)
        if item is not None:
            c.forceDvbUpdate = item
    if not hasattr(config, "misc"):
        return
    if not hasattr(config.misc, "useTransponderTime"):
        try:
            item = _create_bool_config(True)
            if item is not None:
                config.misc.useTransponderTime = item
        except Exception:
            pass

_ensure_config()

def _cfg_bool(item, default=False):
    try:
        return bool(item.value)
    except Exception:
        return default


def _cfg_text(item, default=""):
    try:
        return to_text(item.value)
    except Exception:
        return default


def _set_cfg(item, value):
    try:
        item.setValue(value)
    except Exception:
        try:
            item.value = value
        except Exception:
            return False
    try:
        item.save()
    except Exception:
        pass
    return True


def _server_list():
    raw = DEFAULT_SERVERS
    try:
        c = _dream_config()
        raw = _cfg_text(getattr(c, "servers", None), DEFAULT_SERVERS)
    except Exception:
        pass
    raw = _normalize_server_text(raw)
    servers = []
    for item in raw.split(","):
        item = item.strip()
        if item and item not in servers:
            servers.append(item)
    # Add Google NTP IP as a final fallback in case DNS fails on 1970-date systems
    if "216.239.35.0" not in servers:
        servers.append("216.239.35.0")
    if not servers:
        servers = DEFAULT_SERVERS.split(",")
    return servers


def _timeout():
    try:
        c = _dream_config()
        return int(getattr(getattr(c, "timeout", None), "value"))
    except Exception:
        return 4


def _network_state():
    _log("network_state check started")
    """Return (True/False/None, state_text) for the current network link.

    Tries iNetworkInfo first (OpenPLi / OE-A style), then iNetwork
    (DreamOS style), then falls back to a raw socket probe so the
    plugin works even on images that expose neither API.
    """
    # -- iNetworkInfo (OpenPLi / OE-Alliance images) -----------------------
    if iNetworkInfo is not None:
        try:
            state = iNetworkInfo.getState()
            state_text = to_text(state).strip().lower()
            if state in (True, 1) or state_text in ("online", "up", "connected", "ready"):
                _log("network_state online via iNetworkInfo: %s" % (state_text or "online"))
                return True, state_text or "online"
            if state in (False, 0) or state_text in ("offline", "down", "disconnected", "unreachable"):
                _log("network_state offline via iNetworkInfo: %s" % (state_text or "offline"))
                return False, state_text or "offline"
            _log("network_state unknown via iNetworkInfo: %s" % (state_text or "unknown"))
            return None, state_text or "unknown"
        except Exception:
            pass

    # -- iNetwork (DreamOS / some OE-A images) ----------------------------
    if iNetwork is not None:
        try:
            if hasattr(iNetwork, "isConnected"):
                connected = iNetwork.isConnected()
                if connected:
                    _log("network_state online via iNetwork")
                    return True, "online"
                _log("network_state offline via iNetwork")
                return False, "offline"
        except Exception:
            pass

    # -- Raw socket probe (universal fallback) -----------------------------
    try:
        import socket as _sock
        probe = _sock.socket(_sock.AF_INET, _sock.SOCK_STREAM)
        probe.settimeout(2)
        try:
            probe.connect(("8.8.8.8", 53))
        finally:
            try:
                probe.close()
            except Exception:
                pass
        _log("network_state online via socket probe")
        return True, "online"
    except Exception:
        pass

    _log("network_state unknown after all checks")
    return None, "unknown"


def _load_libc():
    try:
        import ctypes
    except Exception:
        return None, None, "ctypes is not available in this Python image."
    for name in ("libc.so.6", "libc.so"):
        try:
            return ctypes.CDLL(name, use_errno=True), ctypes, ""
        except TypeError:
            try:
                return ctypes.CDLL(name), ctypes, ""
            except Exception:
                pass
        except Exception:
            pass
    return None, ctypes, "libc could not be loaded."


def set_system_time(unix_timestamp):
    libc, ctypes, error = _load_libc()
    if libc is None or ctypes is None:
        return False, error
    try:
        value = float(unix_timestamp)
    except Exception:
        return False, "Invalid timestamp."
    seconds = int(value)
    micro = int(round((value - seconds) * 1000000))
    if micro >= 1000000:
        seconds += 1
        micro -= 1000000
    if micro < 0:
        micro = 0

    # Match libc time_t through c_long. This stays 32-bit on older MIPS/ARM
    # Dreambox images and becomes 64-bit on ARM64 Dreambox One/Two images.
    _time_t = ctypes.c_long

    class Timespec(ctypes.Structure):
        _fields_ = [("tv_sec", _time_t), ("tv_nsec", ctypes.c_long)]

    class Timeval(ctypes.Structure):
        _fields_ = [("tv_sec", _time_t), ("tv_usec", ctypes.c_long)]

    def _update_enigma():
        try:
            c = _dream_config()
            if _cfg_bool(getattr(c, "updateEnigmaTime", None), True):
                if eTimeManager is not None:
                    try:
                        eTimeManager.getInstance().setSystemTime(int(unix_timestamp))
                    except Exception:
                        try:
                            eTimeManager.getInstance().setTime(int(unix_timestamp))
                        except Exception:
                            pass
        except Exception:
            pass

    try:
        if hasattr(libc, "clock_settime"):
            ts = Timespec(seconds, micro * 1000)
            try:
                libc.clock_settime.argtypes = [ctypes.c_int, ctypes.POINTER(Timespec)]
                libc.clock_settime.restype = ctypes.c_int
            except Exception:
                pass
            if libc.clock_settime(0, ctypes.byref(ts)) == 0:
                _update_enigma()
                return True, ""
    except Exception as err:
        _log_exception("clock_settime error", err)

    try:
        if hasattr(libc, "settimeofday"):
            tv = Timeval(seconds, micro)
            try:
                libc.settimeofday.argtypes = [ctypes.POINTER(Timeval), ctypes.c_void_p]
                libc.settimeofday.restype = ctypes.c_int
            except Exception:
                pass
            if libc.settimeofday(ctypes.byref(tv), None) == 0:
                _update_enigma()
                return True, ""
    except Exception as err:
        _log_exception("settimeofday error", err)

    return False, "The system clock could not be changed. Root permissions or image support may be required."


def query_ntp(server, timeout_value):
    _log("query_ntp start: server=%s timeout=%s" % (server, timeout_value))
    packet = b"\x1b" + (b"\0" * (NTP_PACKET_SIZE - 1))
    last_error = ""
    try:
        infos = socket.getaddrinfo(server, NTP_PORT, 0, socket.SOCK_DGRAM)
    except Exception as err:
        _log_exception("DNS lookup failed for %s" % server, err)
        return None, "DNS lookup failed for %s: %s" % (server, to_text(err))
    for family, socktype, proto, _canon, sockaddr in infos:
        sock = None
        try:
            sock = socket.socket(family, socktype, proto)
            sock.settimeout(timeout_value)
            sent = time.time() + NTP_UNIX_EPOCH_DELTA
            _log("query_ntp sendto: server=%s sockaddr=%s" % (server, sockaddr))
            sock.sendto(packet, sockaddr)
            data = sock.recv(NTP_PACKET_SIZE)
            _log("query_ntp received: server=%s bytes=%s" % (server, len(data)))
            received = time.time() + NTP_UNIX_EPOCH_DELTA
            if len(data) < NTP_PACKET_SIZE:
                raise ValueError("short NTP response")
            values = struct.unpack("!12I", data[:NTP_PACKET_SIZE])
            server_recv = values[8] + (float(values[9]) / 4294967296.0)
            server_send = values[10] + (float(values[11]) / 4294967296.0)
            offset = ((server_recv - sent) + (server_send - received)) / 2.0
            _log("query_ntp success: server=%s offset=%s" % (server, offset))
            return time.time() + offset, ""
        except Exception as err:
            last_error = to_text(err)
            _log_exception("query_ntp attempt failed for %s" % server, err)
        try:
            if sock is not None:
                sock.close()
        except Exception:
            pass
    return None, "NTP query to %s failed: %s" % (server, last_error or "no reply")


def sync_ntp(sync_mode="NTP"):
    _log("starting sync (mode: %s)" % sync_mode)
    is_online, _state = _network_state()
    # Only block if explicitly offline. If unknown (None), try anyway.
    if is_online is False:
        error = "Network is unreachable."
        _set_last_sync_result(False, sync_mode, "network", error)
        return False, error
    last_error = ""
    last_server = ""
    servers = _server_list()
    _log("sync_ntp servers=%s timeout=%s network_state=%s" % (servers, _timeout(), _state))
    for server in servers:
        last_server = server
        _log("sync_ntp trying server: %s" % server)
        timestamp, error = query_ntp(server, _timeout())
        if timestamp is None:
            last_error = error
            _log("sync_ntp server failed: %s error=%s" % (server, error))
            continue
        _log("sync_ntp timestamp received from %s: %s" % (server, timestamp))
        ok, error = set_system_time(timestamp)
        _log("set_system_time result: ok=%s error=%s" % (ok, error))
        if ok:
            message = "NTP sync completed with %s.\nNew time: %s" % (server, time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp)))
            _set_last_sync_result(True, sync_mode, server, message)
            return True, message
        last_error = error
    error = last_error or "No NTP server replied."
    _set_last_sync_result(False, sync_mode, last_server or "n/a", error)
    return False, error


def transponder_state():
    try:
        return bool(config.misc.useTransponderTime.value)
    except Exception:
        return False


def set_transponder_state(value):
    try:
        return _set_cfg(config.misc.useTransponderTime, bool(value))
    except Exception:
        return False


def load_skin(screen_name, fallback_skin):
    skin_file = os.path.join(PLUGIN_DIR, "skin.xml")
    skin_data = fallback_skin
    try:
        if os.path.exists(skin_file):
            with open(skin_file, "rb") as skin_handle:
                data = to_text(skin_handle.read())
            start_tag = '<screen name="%s"' % screen_name
            start = data.find(start_tag)
            if start >= 0:
                end = data.find("</screen>", start)
                if end >= 0:
                    skin_data = data[start:end + len("</screen>")]
    except Exception as err:
        _log_exception("skin load error", err)

    if PROFILE.get("is_dreambox"):
        import re
        def _strip_fonts(match):
            tag = match.group(0)
            tag = re.sub(r'\bfont\s*=\s*"[^"]*"', '', tag)
            tag = re.sub(r'\bsecondfont\s*=\s*"[^"]*"', '', tag)
            return tag
        skin_data = re.sub(r'<widget\s+name="config"[^>]*>', _strip_fonts, skin_data)

    return skin_data

def _unused_load_skin(screen_name, fallback_skin):
    skin_file = os.path.join(PLUGIN_DIR, "skin.xml")
    try:
        with open(skin_file, "rb") as skin_handle:
            data = to_text(skin_handle.read())
        start_tag = '<screen name="%s"' % screen_name
        start = data.find(start_tag)
        if start < 0:
            return fallback_skin
        end = data.find("</screen>", start)
        if end < 0:
            return fallback_skin
        return data[start:end + len("</screen>")]
    except Exception as err:
        _log_exception("skin load error", err)
        return fallback_skin


