# -*- coding: utf-8 -*-
from __future__ import print_function

# Created by iet5
# Enigma2 Plugin entry point for DreamTimeSync.
# Safe isolated imports to ensure compatibility with all Python 2.7 and Python 3.x images.

try:
    from Plugins.SystemPlugins.DreamTimeSync import PLUGIN_NAME
    from Plugins.SystemPlugins.DreamTimeSync.core import PLUGIN_ICON, _log_exception
    from Plugins.SystemPlugins.DreamTimeSync.e2compat import PluginDescriptor
    from Plugins.SystemPlugins.DreamTimeSync.screens import DreamTimeSyncMain
    from Plugins.SystemPlugins.DreamTimeSync.startup import sessionstart
except Exception:
    try:
        from . import PLUGIN_NAME
        from .core import PLUGIN_ICON, _log_exception
        from .e2compat import PluginDescriptor
        from .screens import DreamTimeSyncMain
        from .startup import sessionstart
    except Exception:
        from __init__ import PLUGIN_NAME
        from core import PLUGIN_ICON, _log_exception
        from e2compat import PluginDescriptor
        from screens import DreamTimeSyncMain
        from startup import sessionstart


def main(session, **kwargs):
    """Open the plugin's main configuration screen.

    Args:
        session: Active Enigma2 session instance.
    """
    if session is None:
        return
    try:
        session.open(DreamTimeSyncMain)
    except Exception as err:
        _log_exception("main screen open failed", err)


def menu_hook(menuid, **kwargs):
    """Enigma2 menu hook callback.

    Injects the plugin entry under the 'system' (Setup) menu.
    """
    if menuid == "system":
        return [(PLUGIN_NAME, main, "dream_time_sync", 46)]
    return []


def _plugin_where(name):
    """Safely resolve a PluginDescriptor constant by name."""
    try:
        return getattr(PluginDescriptor, name)
    except Exception:
        return None


def _append_plugin_descriptor(result, **kwargs):
    """Create and append a PluginDescriptor instance with fallback protection.

    Handles images with non-standard PluginDescriptor signatures (e.g. missing 'icon').
    """
    try:
        result.append(PluginDescriptor(**kwargs))
        return True
    except TypeError as err:
        _log_exception("PluginDescriptor keyword form failed", err)
        if "icon" in kwargs:
            try:
                # Retry without the 'icon' parameter for legacy compatibility
                retry_kwargs = dict(kwargs)
                del retry_kwargs["icon"]
                result.append(PluginDescriptor(**retry_kwargs))
                return True
            except Exception as retry_err:
                _log_exception("PluginDescriptor no-icon fallback failed", retry_err)
        return False
    except Exception as err:
        _log_exception("PluginDescriptor add failed", err)
        return False


def Plugins(**kwargs):
    """Return the list of PluginDescriptor instances registered by this plugin."""
    result = []
    if PluginDescriptor is None:
        return result

    # 1. Register in Plugin Menu and Extensions Menu.
    # Add each descriptor independently because older images may miss one constant.
    for where_name in ("WHERE_PLUGINMENU", "WHERE_EXTENSIONSMENU"):
        where_value = _plugin_where(where_name)
        if where_value is not None:
            _append_plugin_descriptor(
                result,
                name=PLUGIN_NAME,
                description="Modern time synchronization",
                where=where_value,
                icon=PLUGIN_ICON,
                fnc=main,
            )

    # 2. Register startup triggers.
    # Keep session start and autostart isolated for DreamOS and OE-Alliance compatibility.
    for where_name in ("WHERE_SESSIONSTART", "WHERE_AUTOSTART"):
        where_value = _plugin_where(where_name)
        if where_value is not None:
            _append_plugin_descriptor(result, where=where_value, fnc=sessionstart)

    # 3. Register Setup/System Menu hook.
    where_value = _plugin_where("WHERE_MENU")
    if where_value is not None:
        _append_plugin_descriptor(
            result,
            name=PLUGIN_NAME,
            description="Modern time synchronization",
            where=where_value,
            fnc=menu_hook,
        )

    return result
