# -*- coding: utf-8 -*-
from __future__ import print_function

# Created by iet5
import os
import socket
import struct
import time

# -- Internal imports (three-tier: full path / relative / plain module name) --
try:
    from Plugins.SystemPlugins.DreamTimeSync import (
        _,
        PLUGIN_DIR,
        PLUGIN_NAME,
        compat_print,
        get_asset_path,
        get_plugin_version,
        to_gui_text,
        to_text,
    )
    from Plugins.SystemPlugins.DreamTimeSync.runtime import get_runtime_profile
except Exception:
    try:
        from . import (
            _,
            PLUGIN_DIR,
            PLUGIN_NAME,
            compat_print,
            get_asset_path,
            get_plugin_version,
            to_gui_text,
            to_text,
        )
        from .runtime import get_runtime_profile
    except Exception:
        from __init__ import (
            _,
            PLUGIN_DIR,
            PLUGIN_NAME,
            compat_print,
            get_asset_path,
            get_plugin_version,
            to_gui_text,
            to_text,
        )
        from runtime import get_runtime_profile

try:
    from Plugins.SystemPlugins.DreamTimeSync.e2compat import (
        ConfigBoolean,
        ConfigInteger,
        ConfigSelection,
        ConfigSubsection,
        ConfigText,
        ConfigYesNo,
        config,
        eTimeManager,
        gFont,
        getConfigListEntry,
        iNetwork,
        iNetworkInfo,
        readKeymap,
    )
except Exception:
    try:
        from .e2compat import (
            ConfigBoolean,
            ConfigInteger,
            ConfigSelection,
            ConfigSubsection,
            ConfigText,
            ConfigYesNo,
            config,
            eTimeManager,
            gFont,
            getConfigListEntry,
            iNetwork,
            iNetworkInfo,
            readKeymap,
        )
    except Exception:
        from e2compat import (
            ConfigBoolean,
            ConfigInteger,
            ConfigSelection,
            ConfigSubsection,
            ConfigText,
            ConfigYesNo,
            config,
            eTimeManager,
            gFont,
            getConfigListEntry,
            iNetwork,
            iNetworkInfo,
            readKeymap,
        )

# -- Module-level constants ---------------------------------------------------
VERSION         = get_plugin_version()
LOG_FILE        = "/tmp/DreamTimeSync.log"
NTP_PACKET_SIZE = 48
NTP_PORT        = 123
# Difference in seconds between the NTP epoch (1900-01-01) and the Unix epoch (1970-01-01).
NTP_UNIX_EPOCH_DELTA = 2208988800
LEGACY_DEFAULT_SERVERS = "0.pool.ntp.org,1.pool.ntp.org,time.google.com,time.cloudflare.com"
# Keep all defaults on the same non-smearing time scale.  Start with an
# official Cloudflare IPv4 anycast address so a wrong boot clock or slow DNS
# cannot delay the first request, then fall back to regional/global pools.
DEFAULT_SERVERS = "162.159.200.1,0.africa.pool.ntp.org,1.africa.pool.ntp.org,0.pool.ntp.org"
# List used to keep alive timer connection objects returned by timeout.connect().
TIMER_CONNECTIONS = []
PLUGIN_ICON     = "plugin.png"
PLUGIN_KEYMAP   = get_asset_path("keymap.xml")
KEYMAP_LOADED   = False


# -- Logging helpers ----------------------------------------------------------
def _log(message):
    """Append a timestamped log line to LOG_FILE and print to stdout."""
    try:
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        stamp = "0000-00-00 00:00:00"
    try:
        line = "[DreamTimeSync] %s %s\n" % (stamp, to_text(message))
    except Exception:
        try:
            line = "[DreamTimeSync] %s %s\n" % (stamp, str(message))
        except Exception:
            line = "[DreamTimeSync] %s <log conversion failed>\n" % stamp
    try:
        with open(LOG_FILE, "a") as log_handle:
            log_handle.write(line)
    except Exception:
        pass
    try:
        compat_print(line.rstrip())
    except Exception:
        try:
            print(line.rstrip())
        except Exception:
            pass


def _log_exception(context, err):
    """Log an exception with its context label."""
    try:
        _log("%s: %s" % (context, to_text(err)))
    except Exception:
        _log(context)


# -- Runtime profile (hardware + image + Python version) ----------------------
PROFILE = get_runtime_profile()

_log(
    "module loaded: version=%s target=%s python=%s machine=%s brand=%s image=%s log=%s" % (
        VERSION,
        PROFILE.get("target", "Unknown"),
        PROFILE.get("python_version", "Unknown"),
        PROFILE.get("machine", ""),
        PROFILE.get("brand", ""),
        PROFILE.get("image", ""),
        LOG_FILE,
    )
)

# -- Last sync state ----------------------------------------------------------
# Shared mutable dict updated after every sync attempt.
LAST_SYNC_INFO = {
    "ok":        None,
    "mode":      "NTP",
    "server":    "",
    "summary":   "Never synced",
    "details":   "No NTP synchronization has been attempted yet.",
    "timestamp": "",
}


def _gui(value):
    """Shortcut: return a GUI-safe string."""
    return to_gui_text(value)


# -- Keymap loading -----------------------------------------------------------
def _load_plugin_keymap():
    """Load the plugin keymap from keymap.xml; guard against all failures."""
    global KEYMAP_LOADED
    if KEYMAP_LOADED or readKeymap is None:
        return False
    try:
        if os.path.exists(PLUGIN_KEYMAP):
            readKeymap(PLUGIN_KEYMAP)
            KEYMAP_LOADED = True
            _log("keymap loaded: %s" % PLUGIN_KEYMAP)
            return True
    except Exception as err:
        _log_exception("keymap load error", err)
    return False


_load_plugin_keymap()


# -- NTP server list helpers --------------------------------------------------
def _normalize_server_text(raw):
    """Normalise a comma/semicolon/newline-separated server list string."""
    # Accept semicolons and newlines as additional delimiters.
    text = to_text(raw).replace(";", ",").replace("\r", ",").replace("\n", ",")
    servers = []
    for item in text.split(","):
        server = item.strip()
        if not server:
            continue
        # Deduplicate while preserving insertion order.
        if server not in servers:
            servers.append(server)
    if not servers:
        return DEFAULT_SERVERS
    return ",".join(servers)


# -- dvbdate binary helper ----------------------------------------------------
def _get_dvbdate_command(mode):
    """Return a dvbdate command string for the given mode, or empty string."""
    # Try to find dvbdate binary in standard locations across all images.
    for path in ("/usr/bin/dvbdate", "/bin/dvbdate", "/usr/sbin/dvbdate", "/sbin/dvbdate"):
        if os.path.exists(path):
            if mode == "print":
                return "%s --print" % path
            if mode == "set":
                return "%s --set" % path
            if mode == "force":
                return "%s --set --force" % path
            return path
    return ""


# -- Sync result store --------------------------------------------------------
def _set_last_sync_result(ok, mode, server, message):
    """Update LAST_SYNC_INFO after a sync attempt."""
    global LAST_SYNC_INFO
    state_text  = "SUCCESS" if ok else "FAILED"
    mode_text   = to_text(mode   or "NTP").strip() or "NTP"
    server_text = to_text(server or "n/a").strip() or "n/a"
    timestamp   = time.strftime("%Y-%m-%d %H:%M:%S")
    summary     = "%s | %s | %s" % (mode_text, time.strftime("%H:%M:%S"), server_text)
    details     = (
        "Result: %s\nMode: %s\nServer: %s\nTime: %s\nMessage: %s"
        % (state_text, mode_text, server_text, timestamp, to_text(message or ""))
    )
    LAST_SYNC_INFO.clear()
    LAST_SYNC_INFO.update({
        "ok":         bool(ok),
        "mode":       mode_text,
        "server":     server_text,
        "summary":    summary,
        "details":    details,
        "timestamp":  timestamp,
        "state_text": state_text,
    })
    _log("sync result updated: %s | %s" % (state_text, summary))


def _last_sync_summary():
    """Return the short one-line summary of the last sync attempt."""
    return LAST_SYNC_INFO.get("summary", "Never synced")


def _last_sync_summary_display():
    """Return a prefixed summary string including the sync state tag."""
    summary = _last_sync_summary()
    ok = LAST_SYNC_INFO.get("ok", None)
    if ok is True:
        return "[SUCCESS] | %s" % summary
    if ok is False:
        return "[FAILED] | %s" % summary
    return "[NOT RUN YET] | %s" % summary


def _last_sync_details():
    """Return the full multi-line details of the last sync attempt."""
    return LAST_SYNC_INFO.get("details", "No NTP synchronization has been attempted yet.")


# -- eTimer callback helpers --------------------------------------------------
def _timer_add_callback(timer, callback):
    """Add callback to an Enigma2 eTimer using whichever API the image exposes.

    Tries (in order):
      1. timer.callback list  – classic Enigma2 API
      2. timer.timeout.get()  – newer Enigma2 variant
      3. timer.timeout.connect() – DreamOS / PyQt-style signal
    Returns True on success, False on failure.
    """
    if timer is None:
        _log("timer callback add failed: timer is None")
        return False

    # 1. Classic Enigma2: timer.callback is a plain list.
    try:
        timer_callback = getattr(timer, "callback", None)
        if timer_callback is not None:
            if callback not in timer_callback:
                timer_callback.append(callback)
            _log(
                "timer callback added via timer.callback for %s"
                % getattr(callback, "__name__", "callback")
            )
            return True
    except Exception as err:
        _log_exception("timer.callback append failed", err)

    # 2. Newer variant: timer.timeout.get() returns the callback list.
    try:
        timeout = getattr(timer, "timeout", None)
        if timeout is not None and hasattr(timeout, "get"):
            callbacks = timeout.get()
            if callback not in callbacks:
                callbacks.append(callback)
            _log(
                "timer callback added via timeout.get().append for %s"
                % getattr(callback, "__name__", "callback")
            )
            return True
    except Exception as err:
        _log_exception("timer timeout.get append failed", err)

    # 3. DreamOS / PyQt-style signal connection.
    try:
        timeout = getattr(timer, "timeout", None)
        if timeout is not None and hasattr(timeout, "connect"):
            connection = timeout.connect(callback)
            try:
                TIMER_CONNECTIONS.append(connection)
            except Exception:
                pass
            _log(
                "timer callback added via timeout.connect for %s"
                % getattr(callback, "__name__", "callback")
            )
            return True
    except Exception as err:
        _log_exception("timer timeout.connect failed", err)

    _log("timer callback add failed: no compatible callback API")
    return False


# -- Config access helpers ----------------------------------------------------
def _dream_config():
    """Return config.plugins.DreamTimeSync or None if unavailable."""
    try:
        return config.plugins.DreamTimeSync
    except Exception:
        return None


def _create_bool_config(default_value=False):
    """Create a ConfigYesNo/ConfigBoolean item; try both classes for compatibility."""
    for cls in (ConfigYesNo, ConfigBoolean):
        if cls is None:
            continue
        try:
            return cls(default=bool(default_value))
        except TypeError:
            # Some older images use positional-only constructors.
            try:
                return cls(bool(default_value))
            except Exception:
                pass
        except Exception:
            pass
    return None


def _create_integer_config(default_value, limits=None):
    """Create a ConfigInteger item; handle images that do not accept 'limits'."""
    if ConfigInteger is None:
        return None
    if limits is not None:
        try:
            return ConfigInteger(default=default_value, limits=limits)
        except TypeError:
            pass
        except Exception:
            return None
    try:
        return ConfigInteger(default=default_value)
    except TypeError:
        try:
            return ConfigInteger(default_value)
        except Exception:
            return None
    except Exception:
        return None


def _create_selection_config(choices, default_value):
    """Create a ConfigSelection item; try multiple constructor signatures."""
    if ConfigSelection is None:
        return None
    # Try keyword forms first (most common).
    for kwargs in (
        {"choices": choices, "default": default_value},
        {"choices": choices},
    ):
        try:
            return ConfigSelection(**kwargs)
        except TypeError:
            continue
        except Exception:
            return None
    # Last resort: positional form.
    try:
        return ConfigSelection(choices, default_value)
    except Exception:
        return None


def _append_config_entry(entries, label, item):
    """Append a (label, item) pair to the config list safely."""
    if getConfigListEntry is None or item is None:
        return False
    try:
        entries.append(getConfigListEntry(_gui(label), item))
        return True
    except Exception as err:
        _log_exception("config entry add failed for %s" % label, err)
    return False


def _save_config_item(item):
    """Call item.save() if available; return True on success."""
    if item is None:
        return False
    try:
        item.save()
        return True
    except Exception:
        return False


def _create_servers_config(default_value):
    """Create a ConfigText item for the NTP server list."""
    if ConfigText is None:
        return None
    # Try progressively simpler constructor signatures for maximum compatibility.
    for kwargs in (
        {"default": default_value, "fixed_size": False, "visible_width": 128},
        {"default": default_value, "fixed_size": False, "visible_width": 96},
        {"default": default_value, "fixed_size": False},
        {"default": default_value},
    ):
        try:
            return ConfigText(**kwargs)
        except TypeError:
            continue
        except Exception:
            break
    try:
        return ConfigText(default=default_value)
    except Exception:
        return None


# -- Image family label -------------------------------------------------------
def _get_image_family_label():
    """Return a human-readable label for the detected image family."""
    # Each condition is isolated so that multiple flags can coexist safely.
    if PROFILE.get("is_dreamone_oe26"):
        return "Dreambox One OE2.6"
    if PROFILE.get("is_dreamtwo_oe26"):
        return "Dreambox Two OE2.6"
    if PROFILE.get("is_dreamos"):
        return "DreamOS"
    if PROFILE.get("is_merlin"):
        return "Merlin"
    if PROFILE.get("is_gemini"):
        return "Gemini"
    if PROFILE.get("is_dreamelite"):
        return "Dream-Elite"
    if PROFILE.get("is_openatv"):
        return "OpenATV"
    if PROFILE.get("is_openpli"):
        return "OpenPLi"
    if PROFILE.get("is_openvix"):
        return "OpenViX"
    if PROFILE.get("is_openbh"):
        return "OpenBH"
    if PROFILE.get("is_opendroid"):
        return "OpenDroid"
    if PROFILE.get("is_egami"):
        return "Egami"
    if PROFILE.get("is_vti"):
        return "VTi"
    if PROFILE.get("is_openspa"):
        return "OpenSPA"
    if PROFILE.get("is_openhdf"):
        return "OpenHDF"
    if PROFILE.get("is_opennfr"):
        return "OpenNFR"
    if PROFILE.get("is_pure2"):
        return "PurE2"
    if PROFILE.get("is_satdreamgr"):
        return "SatDreamGr"
    return "Generic image"


# -- Per-device UI profile ----------------------------------------------------
def _get_ui_profile():
    """Return a dict of UI sizing values tuned to the detected device/image/Python.

    Each condition block is kept isolated (not merged into elif chains) so that
    multiple flags can each adjust the values independently.
    """
    ui = {
        "config_separation":  470,
        "config_font":        30,
        "config_item_height": 56,
    }

    # -- Per-device conditions (isolated - do NOT merge into a single elif chain) --
    specific_dreambox = (
        PROFILE.get("is_dm900") or
        PROFILE.get("is_dm920") or
        PROFILE.get("is_dreamone") or
        PROFILE.get("is_dreamtwo")
    )
    if PROFILE.get("is_dm900"):
        ui["config_separation"]  = 430
        ui["config_font"]        = 28
        ui["config_item_height"] = 54
    if PROFILE.get("is_dm920"):
        ui["config_separation"]  = 430
        ui["config_font"]        = 28
        ui["config_item_height"] = 54
    if PROFILE.get("is_dreamone"):
        ui["config_separation"]  = 500
        ui["config_font"]        = 30
        ui["config_item_height"] = 56
    if PROFILE.get("is_dreamtwo"):
        ui["config_separation"]  = 500
        ui["config_font"]        = 30
        ui["config_item_height"] = 56
    if PROFILE.get("is_dreamone_oe26"):
        ui["config_separation"]  = 460
        ui["config_font"]        = 28
        ui["config_item_height"] = 54
    if PROFILE.get("is_dreamtwo_oe26"):
        ui["config_separation"]  = 460
        ui["config_font"]        = 28
        ui["config_item_height"] = 54
    # Generic Dreambox that is not one of the specific models above.
    if PROFILE.get("is_dreambox") and not specific_dreambox:
        ui["config_separation"]  = 450
        ui["config_font"]        = 28
        ui["config_item_height"] = 54

    # -- Per-image conditions (isolated) --------------------------------------
    if PROFILE.get("is_dreamos"):
        ui["config_separation"] = min(ui["config_separation"], 460)
    if PROFILE.get("is_merlin"):
        ui["config_separation"] = min(ui["config_separation"], 460)
    if PROFILE.get("is_gemini"):
        ui["config_separation"] = min(ui["config_separation"], 460)
    if PROFILE.get("is_dreamelite"):
        ui["config_separation"] = min(ui["config_separation"], 460)
    if PROFILE.get("is_openatv"):
        ui["config_separation"] = min(ui["config_separation"], 480)
    if PROFILE.get("is_openpli"):
        ui["config_separation"] = min(ui["config_separation"], 490)
    if PROFILE.get("is_openvix"):
        ui["config_separation"] = min(ui["config_separation"], 480)
    if PROFILE.get("is_openbh"):
        ui["config_separation"] = min(ui["config_separation"], 480)
    if PROFILE.get("is_opendroid"):
        ui["config_separation"] = min(ui["config_separation"], 485)
    if PROFILE.get("is_egami"):
        ui["config_separation"] = min(ui["config_separation"], 490)
    if PROFILE.get("is_vti"):
        ui["config_separation"] = min(ui["config_separation"], 480)
    if PROFILE.get("is_openspa"):
        ui["config_separation"] = min(ui["config_separation"], 490)
    if PROFILE.get("is_openhdf"):
        ui["config_separation"] = min(ui["config_separation"], 480)
    if PROFILE.get("is_opennfr"):
        ui["config_separation"] = min(ui["config_separation"], 480)
    if PROFILE.get("is_pure2"):
        ui["config_separation"] = min(ui["config_separation"], 490)
    if PROFILE.get("is_satdreamgr"):
        ui["config_separation"] = min(ui["config_separation"], 490)

    # -- Per-Python-version conditions (isolated) ------------------------------
    if PROFILE.get("is_python2"):
        # Python 2 (older hardware) uses smaller fonts and tighter layout.
        ui["config_font"]        = min(ui["config_font"], 28)
        ui["config_item_height"] = min(ui["config_item_height"], 54)
        ui["config_separation"]  = min(ui["config_separation"], 450)
    if PROFILE.get("is_python_312_plus"):
        ui["config_font"] = max(ui["config_font"], 29)
    if PROFILE.get("is_python_313_plus"):
        ui["config_font"] = max(ui["config_font"], 30)
    if PROFILE.get("is_python_314_plus"):
        ui["config_font"] = max(ui["config_font"], 30)

    return ui


def _apply_config_profile(config_widget, ui_profile):
    """Apply font/size settings from ui_profile to the config list widget.

    setSeperation (note: typo is part of the Enigma2 API on older images),
    setSeparation (corrected spelling on newer images), and setItemHeight
    are each tried independently so a missing method does not raise.
    """
    config_list = getattr(config_widget, "l", None)
    if config_list is None:
        return
    try:
        # Older images expose 'setSeperation' (intentional typo in E2 source).
        config_list.setSeperation(int(ui_profile.get("config_separation", 470)))
    except Exception:
        try:
            # Newer images expose the correctly spelled 'setSeparation'.
            config_list.setSeparation(int(ui_profile.get("config_separation", 470)))
        except Exception:
            pass
    try:
        config_list.setItemHeight(int(ui_profile.get("config_item_height", 56)))
    except Exception:
        pass


# -- Plugin config initialisation ---------------------------------------------
def _ensure_config():
    """Create any missing config keys under config.plugins.DreamTimeSync."""
    if config is None or ConfigSubsection is None:
        return
    if not hasattr(config, "plugins"):
        return
    if not hasattr(config.plugins, "DreamTimeSync"):
        config.plugins.DreamTimeSync = ConfigSubsection()
    c = config.plugins.DreamTimeSync

    # Each key is created only when absent so existing user values are preserved.
    if not hasattr(c, "pluginEnabled"):
        item = _create_bool_config(True)
        if item is not None:
            c.pluginEnabled = item
    if not hasattr(c, "syncOnStart"):
        item = _create_bool_config(True)
        if item is not None:
            c.syncOnStart = item
    if not hasattr(c, "showMessages"):
        item = _create_bool_config(True)
        if item is not None:
            c.showMessages = item
    if not hasattr(c, "preferNtp"):
        item = _create_bool_config(True)
        if item is not None:
            c.preferNtp = item
    if not hasattr(c, "allowDvbTime"):
        item = _create_bool_config(True)
        if item is not None:
            c.allowDvbTime = item
    if not hasattr(c, "servers"):
        item = _create_servers_config(DEFAULT_SERVERS)
        if item is not None:
            c.servers = item
    else:
        try:
            saved_servers = _normalize_server_text(c.servers.value)
            if saved_servers == _normalize_server_text(LEGACY_DEFAULT_SERVERS):
                c.servers.setValue(DEFAULT_SERVERS)
                c.servers.save()
                _log("upgraded legacy default NTP server list")
        except Exception as err:
            _log_exception("default NTP server list upgrade failed", err)
    if not hasattr(c, "timeout"):
        item = _create_integer_config(4, limits=(1, 15))
        if item is not None:
            c.timeout = item
    if not hasattr(c, "retryInternetOnStart"):
        item = _create_bool_config(True)
        if item is not None:
            c.retryInternetOnStart = item
    if not hasattr(c, "internetRetryWindowSec"):
        item = _create_integer_config(30, limits=(5, 300))
        if item is not None:
            c.internetRetryWindowSec = item
    if not hasattr(c, "internetRetryFirstDelayMin"):
        item = _create_integer_config(5, limits=(1, 1440))
        if item is not None:
            c.internetRetryFirstDelayMin = item
    if not hasattr(c, "checkDvbOnStart"):
        item = _create_bool_config(False)
        if item is not None:
            c.checkDvbOnStart = item
    if not hasattr(c, "updateEnigmaTime"):
        item = _create_bool_config(True)
        if item is not None:
            c.updateEnigmaTime = item
    if not hasattr(c, "forceDvbUpdate"):
        item = _create_bool_config(False)
        if item is not None:
            c.forceDvbUpdate = item

    # Create config.misc.useTransponderTime only if config.misc already exists.
    if not hasattr(config, "misc"):
        return
    if not hasattr(config.misc, "useTransponderTime"):
        try:
            item = _create_bool_config(True)
            if item is not None:
                config.misc.useTransponderTime = item
        except Exception:
            pass


_ensure_config()


# -- Config value accessors ---------------------------------------------------
def _cfg_bool(item, default=False):
    """Return the boolean value of a config item, or default on error."""
    try:
        return bool(item.value)
    except Exception:
        return default


def _cfg_text(item, default=""):
    """Return the text value of a config item, or default on error."""
    try:
        return to_text(item.value)
    except Exception:
        return default


def _set_cfg(item, value):
    """Set a config item value using setValue() then item.value as fallback."""
    try:
        item.setValue(value)
    except Exception:
        try:
            item.value = value
        except Exception:
            return False
    try:
        item.save()
    except Exception:
        pass
    return True


# -- Server list / timeout ----------------------------------------------------
def _server_list():
    """Return an ordered list of NTP server hostnames/IPs to try."""
    raw = DEFAULT_SERVERS
    try:
        c   = _dream_config()
        raw = _cfg_text(getattr(c, "servers", None), DEFAULT_SERVERS)
    except Exception:
        pass
    raw = _normalize_server_text(raw)
    # Upgrade only the plugin's previous untouched default.  Never overwrite a
    # server list the user has customized.
    if raw == _normalize_server_text(LEGACY_DEFAULT_SERVERS):
        raw = DEFAULT_SERVERS
    servers = []
    for item in raw.split(","):
        item = item.strip()
        if item and item not in servers:
            servers.append(item)
    if not servers:
        servers = DEFAULT_SERVERS.split(",")
    return servers


def _timeout():
    """Return the configured NTP timeout value in seconds."""
    try:
        c = _dream_config()
        return int(getattr(getattr(c, "timeout", None), "value"))
    except Exception:
        return 4


# -- Network state detection --------------------------------------------------
def _network_state():
    """Return (True/False/None, state_text) for the current network link.

    Tries iNetworkInfo first (OpenPLi / OE-A style), then iNetwork
    (DreamOS style), then falls back to a raw socket probe so the
    plugin works even on images that expose neither API.

    Returns:
        (True,  str) – network is online
        (False, str) – network is explicitly offline
        (None,  str) – state cannot be determined (treat as possibly online)
    """
    _log("network_state check started")

    # -- iNetworkInfo (OpenPLi / OE-Alliance images) --------------------------
    if iNetworkInfo is not None:
        try:
            state      = iNetworkInfo.getState()
            state_text = to_text(state).strip().lower()
            if state in (True, 1) or state_text in ("online", "up", "connected", "ready"):
                _log("network_state online via iNetworkInfo: %s" % (state_text or "online"))
                return True, state_text or "online"
            if state in (False, 0) or state_text in ("offline", "down", "disconnected", "unreachable"):
                _log("network_state offline via iNetworkInfo: %s" % (state_text or "offline"))
                return False, state_text or "offline"
            _log("network_state unknown via iNetworkInfo: %s" % (state_text or "unknown"))
            return None, state_text or "unknown"
        except Exception:
            pass

    # -- iNetwork (DreamOS / some OE-A images) --------------------------------
    if iNetwork is not None:
        try:
            if hasattr(iNetwork, "isConnected"):
                connected = iNetwork.isConnected()
                if connected:
                    _log("network_state online via iNetwork")
                    return True, "online"
                _log("network_state offline via iNetwork")
                return False, "offline"
        except Exception:
            pass

    # -- Raw socket probe (universal fallback) --------------------------------
    try:
        import socket as _sock
        probe = _sock.socket(_sock.AF_INET, _sock.SOCK_STREAM)
        probe.settimeout(0.75)
        try:
            # Probe Google DNS; no data is exchanged – just checks TCP reachability.
            probe.connect(("8.8.8.8", 53))
        finally:
            try:
                probe.close()
            except Exception:
                pass
        _log("network_state online via socket probe")
        return True, "online"
    except Exception:
        pass

    _log("network_state unknown after all checks")
    return None, "unknown"


# -- libc loading (for clock_settime / settimeofday) --------------------------
def _load_libc():
    """Load libc.so via ctypes; return (libc, ctypes, error_string)."""
    try:
        import ctypes
    except Exception:
        return None, None, "ctypes is not available in this Python image."
    # Try both common libc names used across different Linux distributions / architectures.
    for name in ("libc.so.6", "libc.so"):
        try:
            return ctypes.CDLL(name, use_errno=True), ctypes, ""
        except TypeError:
            # Some older ctypes versions do not accept use_errno.
            try:
                return ctypes.CDLL(name), ctypes, ""
            except Exception:
                pass
        except Exception:
            pass
    return None, ctypes, "libc could not be loaded."


# -- System clock setter ------------------------------------------------------
def set_system_time(unix_timestamp):
    """Set the system clock to unix_timestamp (float seconds since Unix epoch).

    Tries clock_settime first (preferred, nanosecond resolution), then falls
    back to settimeofday (microsecond resolution).  Also notifies eTimeManager
    if configured, so Enigma2 reflects the new time immediately.

    Returns:
        (True,  "")    – success
        (False, str)   – failure with reason
    """
    libc, ctypes, error = _load_libc()
    if libc is None or ctypes is None:
        return False, error
    try:
        value = float(unix_timestamp)
    except Exception:
        return False, "Invalid timestamp."
    seconds = int(value)
    micro   = int(round((value - seconds) * 1000000))
    if micro >= 1000000:
        seconds += 1
        micro   -= 1000000
    if micro < 0:
        micro = 0

    # Match libc time_t through c_long. This stays 32-bit on older MIPS/ARM
    # Dreambox images and becomes 64-bit on ARM64 Dreambox One/Two images.
    _time_t = ctypes.c_long

    class Timespec(ctypes.Structure):
        _fields_ = [("tv_sec", _time_t), ("tv_nsec", ctypes.c_long)]

    class Timeval(ctypes.Structure):
        _fields_ = [("tv_sec", _time_t), ("tv_usec", ctypes.c_long)]

    def _update_enigma():
        """Notify eTimeManager so Enigma2 picks up the new system time."""
        try:
            c = _dream_config()
            if _cfg_bool(getattr(c, "updateEnigmaTime", None), True):
                if eTimeManager is not None:
                    try:
                        eTimeManager.getInstance().setSystemTime(int(unix_timestamp))
                    except Exception:
                        try:
                            eTimeManager.getInstance().setTime(int(unix_timestamp))
                        except Exception:
                            pass
        except Exception:
            pass

    # Attempt 1: clock_settime (POSIX, preferred – nanosecond precision).
    try:
        if hasattr(libc, "clock_settime"):
            ts = Timespec(seconds, micro * 1000)
            try:
                libc.clock_settime.argtypes = [ctypes.c_int, ctypes.POINTER(Timespec)]
                libc.clock_settime.restype  = ctypes.c_int
            except Exception:
                pass
            if libc.clock_settime(0, ctypes.byref(ts)) == 0:
                _update_enigma()
                return True, ""
    except Exception as err:
        _log_exception("clock_settime error", err)

    # Attempt 2: settimeofday (POSIX legacy – microsecond precision).
    try:
        if hasattr(libc, "settimeofday"):
            tv = Timeval(seconds, micro)
            try:
                libc.settimeofday.argtypes = [ctypes.POINTER(Timeval), ctypes.c_void_p]
                libc.settimeofday.restype  = ctypes.c_int
            except Exception:
                pass
            if libc.settimeofday(ctypes.byref(tv), None) == 0:
                _update_enigma()
                return True, ""
    except Exception as err:
        _log_exception("settimeofday error", err)

    return False, "The system clock could not be changed. Root permissions or image support may be required."


# -- NTP query ----------------------------------------------------------------
def query_ntp(server, timeout_value):
    """Send a single NTP request and return (unix_timestamp, error_string).

    Returns (float, "") on success or (None, reason) on failure.
    Iterates over all addresses returned by getaddrinfo() to handle IPv6 and
    multiple A records transparently.
    """
    _log("query_ntp start: server=%s timeout=%s" % (server, timeout_value))
    # Construct a minimal NTP client packet (LI=0, VN=3, Mode=3).
    packet     = b"\x1b" + (b"\0" * (NTP_PACKET_SIZE - 1))
    last_error = ""
    try:
        infos = socket.getaddrinfo(server, NTP_PORT, 0, socket.SOCK_DGRAM)
        # Old Dreambox images can return an unreachable IPv6 address first and
        # wait for the full timeout before trying IPv4.  Prefer IPv4 while still
        # retaining IPv6 as a fallback.
        infos.sort(key=lambda info: 0 if info[0] == socket.AF_INET else 1)
    except Exception as err:
        _log_exception("DNS lookup failed for %s" % server, err)
        return None, "DNS lookup failed for %s: %s" % (server, to_text(err))
    for family, socktype, proto, _canon, sockaddr in infos:
        sock = None
        try:
            sock = socket.socket(family, socktype, proto)
            sock.settimeout(timeout_value)
            sent = time.time() + NTP_UNIX_EPOCH_DELTA
            _log("query_ntp sendto: server=%s sockaddr=%s" % (server, sockaddr))
            sock.sendto(packet, sockaddr)
            data = sock.recv(NTP_PACKET_SIZE)
            _log("query_ntp received: server=%s bytes=%s" % (server, len(data)))
            received = time.time() + NTP_UNIX_EPOCH_DELTA
            if len(data) < NTP_PACKET_SIZE:
                raise ValueError("short NTP response")
            # Unpack 12 unsigned 32-bit integers from the NTP response.
            values      = struct.unpack("!12I", data[:NTP_PACKET_SIZE])
            server_recv = values[8]  + (float(values[9])  / 4294967296.0)
            server_send = values[10] + (float(values[11]) / 4294967296.0)
            # Compute clock offset using the four-timestamp algorithm.
            offset = ((server_recv - sent) + (server_send - received)) / 2.0
            _log("query_ntp success: server=%s offset=%s" % (server, offset))
            return time.time() + offset, ""
        except Exception as err:
            last_error = to_text(err)
            _log_exception("query_ntp attempt failed for %s" % server, err)
        # Ensure the socket is closed even when an exception occurs.
        try:
            if sock is not None:
                sock.close()
        except Exception:
            pass
    return None, "NTP query to %s failed: %s" % (server, last_error or "no reply")


# -- High-level sync entry point ----------------------------------------------
def sync_ntp(sync_mode="NTP", network_checked=False):
    """Try each server in the configured list until one succeeds.

    Returns (True, message) on success or (False, error) on failure.
    Network state is checked first; explicitly offline is the only condition
    that prevents all attempts (unknown state still attempts a sync).
    """
    _log("starting sync (mode: %s)" % sync_mode)
    if network_checked:
        is_online, _state = None, "prechecked"
    else:
        is_online, _state = _network_state()
    # Only block if explicitly offline. If unknown (None), try anyway.
    if is_online is False:
        error = "Network is unreachable."
        _set_last_sync_result(False, sync_mode, "network", error)
        return False, error
    last_error  = ""
    last_server = ""
    servers     = _server_list()
    timeout_value = _timeout()
    if to_text(sync_mode).lower().startswith("startup"):
        timeout_value = min(timeout_value, 2)
    _log("sync_ntp servers=%s timeout=%s network_state=%s" % (servers, timeout_value, _state))
    for server in servers:
        last_server = server
        _log("sync_ntp trying server: %s" % server)
        timestamp, error = query_ntp(server, timeout_value)
        if timestamp is None:
            last_error = error
            _log("sync_ntp server failed: %s error=%s" % (server, error))
            continue
        _log("sync_ntp timestamp received from %s: %s" % (server, timestamp))
        ok, error = set_system_time(timestamp)
        _log("set_system_time result: ok=%s error=%s" % (ok, error))
        if ok:
            message = "NTP sync completed with %s.\nNew time: %s" % (
                server,
                time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp)),
            )
            _set_last_sync_result(True, sync_mode, server, message)
            return True, message
        last_error = error
    error = last_error or "No NTP server replied."
    _set_last_sync_result(False, sync_mode, last_server or "n/a", error)
    return False, error


# -- DVB / transponder time ---------------------------------------------------
def transponder_state():
    """Return True if config.misc.useTransponderTime is enabled."""
    try:
        return bool(config.misc.useTransponderTime.value)
    except Exception:
        return False


def set_transponder_state(value):
    """Enable or disable config.misc.useTransponderTime."""
    try:
        return _set_cfg(config.misc.useTransponderTime, bool(value))
    except Exception:
        return False


# -- Skin loading helper ------------------------------------------------------
def load_skin(screen_name, fallback_skin):
    """Load a screen skin block from skin.xml; return fallback_skin on error.

    For Dreambox images the font/secondfont attributes are stripped from the
    config widget tag because DreamOS ignores external font overrides and the
    attributes cause a harmless but noisy warning in the log.
    """
    skin_file = os.path.join(PLUGIN_DIR, "skin.xml")
    skin_data  = fallback_skin
    try:
        if os.path.exists(skin_file):
            with open(skin_file, "rb") as skin_handle:
                data = to_text(skin_handle.read())
            start_tag = '<screen name="%s"' % screen_name
            start     = data.find(start_tag)
            if start >= 0:
                end = data.find("</screen>", start)
                if end >= 0:
                    skin_data = data[start:end + len("</screen>")]
    except Exception as err:
        _log_exception("skin load error", err)

    # Strip font attributes on Dreambox images to avoid spurious warnings.
    if PROFILE.get("is_dreambox"):
        import re
        def _strip_fonts(match):
            tag = match.group(0)
            tag = re.sub(r'\bfont\s*=\s*"[^"]*"',       "", tag)
            tag = re.sub(r'\bsecondfont\s*=\s*"[^"]*"', "", tag)
            return tag
        skin_data = re.sub(r'<widget\s+name="config"[^>]*>', _strip_fonts, skin_data)

    return skin_data


# -- Kept for reference only (not called by any active code path) -------------
def _unused_load_skin(screen_name, fallback_skin):
    """Original simple skin loader kept here for historical reference."""
    skin_file = os.path.join(PLUGIN_DIR, "skin.xml")
    try:
        with open(skin_file, "rb") as skin_handle:
            data = to_text(skin_handle.read())
        start_tag = '<screen name="%s"' % screen_name
        start     = data.find(start_tag)
        if start < 0:
            return fallback_skin
        end = data.find("</screen>", start)
        if end < 0:
            return fallback_skin
        return data[start:end + len("</screen>")]
    except Exception as err:
        _log_exception("skin load error", err)
        return fallback_skin
